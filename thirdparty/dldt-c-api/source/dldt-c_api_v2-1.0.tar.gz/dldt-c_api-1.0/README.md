# DLDT additional c_api library based on toolkit
- Please install OpenVINO toolkit as super user and run script build.sh
- It was verified on Ubuntu 16.04
- If you are using open source dldt, please set the env correctly or use the prebuilt bundle.
- It's not an official version and no support can be provided
